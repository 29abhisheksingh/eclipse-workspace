package com.cg.exceptions;

public class OutOfWarrantyException {

}
