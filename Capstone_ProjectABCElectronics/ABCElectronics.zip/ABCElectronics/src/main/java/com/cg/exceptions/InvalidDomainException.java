package com.cg.exceptions;

public class InvalidDomainException extends Exception
{

	public InvalidDomainException(String message) 
	{
		super(message);
		
	}

	
	
}
