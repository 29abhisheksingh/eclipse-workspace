package com.example.demo.Exceptions;

public class InvalidModelNumberException {

}
