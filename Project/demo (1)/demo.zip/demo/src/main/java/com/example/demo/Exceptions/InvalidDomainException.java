package com.example.demo.Exceptions;

public class InvalidDomainException extends Exception
{

	public InvalidDomainException(String message) 
	{
		super(message);
		
	}

	
	
}
