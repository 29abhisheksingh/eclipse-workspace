package com.cg.exceptions;

public class InvalidModelNumberException {

}
